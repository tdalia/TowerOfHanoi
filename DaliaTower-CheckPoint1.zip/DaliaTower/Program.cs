﻿using System;
using System.Collections.Generic;
using TowerOfHanoiLibrary;
using static System.Console;

namespace DaliaTowerUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool continueYN = true;
            TowerUI ui = null;
            int moveAction = 0;

            do
            {
                Console.Clear();
                ui = new TowerUI();
                moveAction = 0;

                int discs = ui.InputNumberOfDiscs();
                if (ui.CreateTowers())
                {
                    
                    moveAction = ui.InputMoveAction();
                    /*if (moveAction == -1)
                    {
                        //break; // Exit the app
                    }*/

                    // List Moves
                    ui.ViewMoveRecords();
                }

                // Ask to continue
                Write("\n\nWant to try again (press 'Y' to continue): ");
                string inputStr = ReadKey().KeyChar.ToString().ToUpper();
                continueYN = inputStr == "Y" ? true : false;
            } while (continueYN);

            ui = null;
            WriteLine("\n\nBye. See you again! Press any key to finish up.");
            ReadKey();
            return;
        }


    }

    class TowerUI
    {
        public int NumberOfDiscs { get; set; } 
        private Towers towers = null;
        private Queue<MoveRecord> moveRecords = null;

        public TowerUI() { }

        public int InputNumberOfDiscs()
        {
            int discs = 0;
            int defaultDiscs = 3;
            bool valid = false;
            do
            {
                Write($"Enter Number of discs in your tower (default is {defaultDiscs}, max is 9): ");
                ConsoleKeyInfo consoleKeyInfo = ReadKey();
                if (consoleKeyInfo.Key == ConsoleKey.Enter)
                {
                    discs = defaultDiscs;
                    valid = true;
                }
                else
                {
                    string inputStr = consoleKeyInfo.KeyChar.ToString();
                    valid = Int32.TryParse(inputStr, out discs);
                    if (!valid)    // || (valid && (discs < 1 || discs > 9)))  //  Handled cause of InvalidHeightException 
                    {
                        WriteLine("\nInvalid Input: Enter a number between 1-9.");
                        valid = false;
                    }
                }

                NumberOfDiscs = discs;

            } while (!valid);

            return discs;
        }

        public bool CreateTowers()
        {
            /** Handled cause of InvalidHeightException
            if (NumberOfDiscs <= 0)
            {
                InputNumberOfDiscs();
            }
            */
            try
            {
                towers = new Towers(NumberOfDiscs);
                moveRecords = new Queue<MoveRecord>();
            }catch (InvalidHeightException he)
            {
                WriteLine($"\n InvalidHeightException: {he.Message}");
                return false;
            }
            return true;
        }

        public Towers GetTowers() => towers;

        public int InputMoveAction()
        {
            string inputStr, statusMsg = "";
            int fromPole = 0, toPole = 0, moveNum;
            bool valid = false;
            bool moveCancelled = false;

            Console.Clear();
            TowerUtilities.DisplayTowers(GetTowers());

            do
            {
                fromPole = 0; toPole = 0;
                moveCancelled = false;

                moveNum = towers.NumberOfMoves +1;
                WriteLine($"\nMove {moveNum}:");

                // From tower Input
                do
                {
                    Write("\nEnter 'from' tower number (1 – 3), or ‘x’ to quit : ");
                    inputStr = ReadKey().KeyChar.ToString().Trim().ToUpper();
                    if (inputStr == "X")
                    {
                        WriteLine($"\nWell, you hand in there fo {towers.NumberOfMoves} moves. Nice try.");
                        return -1;
                    }

                    // From Pole
                    valid = IsPoleInputValid(inputStr, out fromPole);
                    if (!valid)
                    {
                        WriteLine("\nInvalid value. Tower value should be (1 – 3) or press 'x'");
                    }
                } while (!valid);

                // To tower Input
                do
                {
                    Write("\nEnter 'to' tower number (1 – 3), or enter to cancel : ");
                    ConsoleKeyInfo consoleKeyInfo = ReadKey();
                    if (consoleKeyInfo.Key == ConsoleKey.Enter)
                    {
                        moveCancelled = true;
                        WriteLine("\nMove cancelled.");
                        break;
                    }
                    else
                    {
                        inputStr = consoleKeyInfo.KeyChar.ToString().Trim().ToUpper();
                        valid = IsPoleInputValid(inputStr, out toPole);
                        if (!valid)
                        {
                            WriteLine("\nInvalid value. Tower value should be (1 – 3) or press 'enter'");
                        }
                    }
                } while (!valid);

                if(moveCancelled)
                {
                    continue;
                }

                // Move operation
                try
                {
                    MoveRecord record = towers.Move(fromPole, toPole);
                    moveRecords.Enqueue(record);
                    statusMsg = $"Complete. Successfully moved disc from tower {fromPole} to tower {toPole}";

                    Console.Clear();
                    TowerUtilities.DisplayTowers(GetTowers());
                    WriteLine($"\nMove {towers.NumberOfMoves} complete. Successfully moved disc from tower {fromPole} to tower {toPole}");

                    // Game is complete
                    if (towers.IsComplete)
                    {
                        string msg = towers.NumberOfMoves == towers.MinimumPossibleMoves ?
                            $"It took you {towers.NumberOfMoves} moves. Congrats! That's the minimum!" :
                            $"It took you {towers.NumberOfMoves} moves. Not bad, but it can be done in {towers.MinimumPossibleMoves} moves. Try again.";

                        WriteLine(msg);
                    }
                }
                catch (Exception ex)
                {
                    WriteLine($"\n{ex.GetType().Name}: {ex.Message}");
                }

            } while (! towers.IsComplete);

            return 0;
        }

        public void ViewMoveRecords()
        {
            string viewYN;
            do
            {
                Write("\n\nWould you like to see a list of the moved you made? ('Y' or 'N'): ");
                viewYN = ReadKey().KeyChar.ToString().ToUpper();
            } while (viewYN != "Y" && viewYN != "N");

            if (viewYN == "N")
                return;

            WriteLine("\n");
            int i = 1;
            foreach (MoveRecord record in moveRecords)
            {
                WriteLine($"   {i++}. Disc {record.DiscNumber} moved from tower {record.FromPole} to tower {record.ToPole}");
            }

            return;
        }

        private bool IsPoleInputValid(string poleStr, out int poleNum)
        {
            bool valid = Int32.TryParse(poleStr, out poleNum);
            if (valid && (poleNum < 1 || poleNum > 3))
            {
                valid = false;
            }

            return valid;
        }


    }
}
